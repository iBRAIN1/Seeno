document.getElementById("question-form").onsubmit = function (e) {
  e.preventDefault();
  const question = document.getElementById("new-question").value.trim();
  const answer = document.getElementById("new-answer").value.trim();
  if (question && answer) {
    const questions = JSON.parse(localStorage.getItem("questions") || "[]");
    questions.push({ q: question, a: answer });
    localStorage.setItem("questions", JSON.stringify(questions));
    document.getElementById("status").textContent = "تمت الإضافة بنجاح!";
    document.getElementById("question-form").reset();
  }
};
