let questions = JSON.parse(localStorage.getItem("questions") || "[]");
let currentIndex = -1;

document.getElementById("next-question").onclick = function () {
  if (questions.length === 0) {
    document.getElementById("question").textContent = "لا توجد أسئلة. الرجاء الإضافة من لوحة التحكم.";
    return;
  }
  currentIndex = (currentIndex + 1) % questions.length;
  document.getElementById("question").textContent = questions[currentIndex].q;
  document.getElementById("answer").style.display = "none";
};

document.getElementById("show-answer").onclick = function () {
  if (currentIndex >= 0 && questions.length > 0) {
    document.getElementById("answer").textContent = questions[currentIndex].a;
    document.getElementById("answer").style.display = "block";
  }
};
